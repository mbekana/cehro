export interface Category {
  id: number;
  name: string;
  remark: string;
}
