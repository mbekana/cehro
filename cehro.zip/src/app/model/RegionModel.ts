export interface Region {
  id: number;
  name: string;
  population: number;
}
